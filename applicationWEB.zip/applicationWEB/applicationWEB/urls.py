# Importation des modules nécessaires pour la configuration des URLs
from django.contrib import admin  # Importation du module pour l'admin de Django
from django.urls import path, include  # Importation des fonctions pour définir les URL et inclure d'autres fichiers URL
from django.conf import settings  # Importation des paramètres de configuration de Django
from django.conf.urls.static import static  # Importation de la fonction pour gérer les fichiers statiques

# Définition de la liste des URL pour l'application
urlpatterns = [
    path('admin/', admin.site.urls),  # URL pour accéder à l'interface d'administration de Django
    path('', include('app_name.urls')),  # Inclut les URL de l'application 'app_name'
]

# Si l'application est en mode DEBUG (généralement en développement)
if settings.DEBUG:
    # Ajoute des URL pour servir les fichiers statiques pendant le développement
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
