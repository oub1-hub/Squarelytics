# Importation des modules nécessaires pour l'application ASGI
import os  # Pour interagir avec les variables d'environnement
from django.core.asgi import get_asgi_application  # Importation de la fonction pour obtenir l'application ASGI

# Définition de la variable d'environnement pour les paramètres de configuration de Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'applicationWEB.settings')  # Spécifie quel fichier de paramètres Django utiliser

# Obtention de l'application ASGI pour gérer les requêtes ASGI
application = get_asgi_application()  # Crée et retourne l'application ASGI qui sera utilisée pour la gestion des requêtes

