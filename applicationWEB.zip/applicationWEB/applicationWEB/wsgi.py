# Importation des modules nécessaires pour l'application WSGI
import os  # Pour interagir avec les variables d'environnement
from django.core.wsgi import get_wsgi_application  # Importation de la fonction pour obtenir l'application WSGI

# Définition de la variable d'environnement pour les paramètres de configuration de Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'applicationWEB.settings')  # Spécifie quel fichier de paramètres Django utiliser

# Obtention de l'application WSGI pour gérer les requêtes HTTP
application = get_wsgi_application()  # Crée et retourne l'application WSGI qui sera utilisée pour la gestion des requêtes HTTP
