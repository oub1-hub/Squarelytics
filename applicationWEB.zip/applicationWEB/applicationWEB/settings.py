# Importation des modules nécessaires
import os  # Pour interagir avec le système d'exploitation
from pathlib import Path  # Pour faciliter la gestion des chemins de fichiers

# Définir le répertoire de base du projet
BASE_DIR = Path(__file__).resolve().parent.parent  # Chemin absolu vers le répertoire principal du projet

# Clé secrète pour la sécurité (ne jamais partager cette clé en production)
SECRET_KEY = 'lucy'  # Remplacez ceci par une clé secrète générée en production

# Mode de débogage activé pour le développement
DEBUG = True  # Doit être False en production pour des raisons de sécurité

# Hôtes autorisés à accéder à l'application
ALLOWED_HOSTS = ['127.0.0.1', 'localhost']  # Limité à localhost en développement

# Applications installées dans le projet
INSTALLED_APPS = [
    'django.contrib.admin',  # L'interface d'administration Django
    'django.contrib.auth',  # Système d'authentification de Django
    'django.contrib.contenttypes',  # Pour les modèles génériques
    'django.contrib.sessions',  # Pour la gestion des sessions
    'django.contrib.messages',  # Pour afficher les messages
    'django.contrib.staticfiles',  # Pour la gestion des fichiers statiques
    'app_name',  # Nom de votre application spécifique
]

# Middleware pour le traitement des requêtes et réponses
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',  # Middleware pour la sécurité
    'django.contrib.sessions.middleware.SessionMiddleware',  # Middleware pour les sessions
    'django.middleware.common.CommonMiddleware',  # Middleware pour les tâches courantes (par ex. redirection)
    'django.middleware.csrf.CsrfViewMiddleware',  # Middleware pour la protection contre les attaques CSRF
    'django.contrib.auth.middleware.AuthenticationMiddleware',  # Middleware pour l'authentification
    'django.contrib.messages.middleware.MessageMiddleware',  # Middleware pour la gestion des messages
    'django.middleware.clickjacking.XFrameOptionsMiddleware',  # Middleware pour éviter les attaques de type clickjacking
]

# Configuration des URLs du projet
ROOT_URLCONF = 'applicationWEB.urls'  # Fichier URL principal du projet

# Paramètres des templates (pour rendre les pages HTML)
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',  # Utilisation du moteur de templates Django
        'DIRS': [BASE_DIR / 'templates'],  # Dossier où Django recherchera les templates
        'APP_DIRS': True,  # Permet à Django de chercher des templates dans les répertoires des applications
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',  # Permet d'afficher des informations de débogage
                'django.template.context_processors.request',  # Permet de gérer les requêtes HTTP
                'django.contrib.auth.context_processors.auth',  # Permet de gérer l'authentification
                'django.contrib.messages.context_processors.messages',  # Permet d'afficher les messages de l'application
            ],
        },
    },
]

# Configuration WSGI (pour le déploiement sur un serveur web)
WSGI_APPLICATION = 'applicationWEB.wsgi.application'

# Configuration ASGI (utilisé pour le support WebSocket et autres protocoles)
ASGI_APPLICATION = 'applicationWEB.asgi.application'

# Paramètres de la base de données
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',  # Utilisation de SQLite pour le développement (à remplacer pour la production)
        'NAME': BASE_DIR / 'db.sqlite3',  # Nom du fichier de la base de données
    }
}

# Validation des mots de passe
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',  # Validation de similarité des attributs
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',  # Validation de la longueur minimale du mot de passe
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',  # Validation contre les mots de passe communs
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',  # Validation contre les mots de passe numériques uniquement
    },
]

# Paramètres de la langue et du fuseau horaire
LANGUAGE_CODE = 'en-us'  # Langue de l'application
TIME_ZONE = 'UTC'  # Fuseau horaire utilisé (UTC par défaut)

USE_I18N = True  # Active le support de l'internationalisation
USE_TZ = True  # Active le support des fuseaux horaires

# Paramètres des fichiers statiques
STATIC_URL = '/static/'  # URL de base pour accéder aux fichiers statiques

# Emplacement des fichiers statiques pendant le développement
STATICFILES_DIRS = [BASE_DIR / "static"]  # Dossier contenant les fichiers statiques (ex : CSS, JS, images)

# Emplacement des fichiers statiques en production (à configurer pour la collecte de fichiers statiques)
STATIC_ROOT = BASE_DIR / "staticfiles"  # Dossier où les fichiers statiques sont collectés pour le déploiement
