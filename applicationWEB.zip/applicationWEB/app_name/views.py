from builtins import Exception, IndexError, ValueError, int, len, open
import os
from django.conf import settings
from django.shortcuts import render, redirect
from django.http import FileResponse, HttpResponse
from .forms import ColumnAnalysisForm, UploadFileForm, VisualisationForm , DataCleaningForm
import pandas as pd
import logging
import matplotlib
matplotlib.use('Agg')  # Utilise un backend sans interface graphique
import matplotlib.pyplot as plt
import seaborn as sns  # type: ignore
from io import BytesIO
import base64

logger = logging.getLogger(__name__)

# Variable globale pour stocker temporairement le DataFrame téléchargé
uploaded_df = None
def serve_static_file(request):
    file_path = os.path.join(settings.BASE_DIR, 'static', 'images', 'Squarelyti.png')
    return FileResponse(open(file_path, 'rb'), content_type='image/png')
def about(request):
    return render(request, 'about.html')
def contact(request):
    return render(request, 'contact.html')
def upload(request):
    return render(request, 'upload.html')
def index(request):
    return render(request, 'index_data.html')

def handle_uploaded_file(file):
    """
    Fonction pour lire le fichier CSV et retourner un DataFrame pandas.
    """
    try:
        return pd.read_csv(file)
    except Exception as e:
        logger.error(f"Erreur lors de la lecture du fichier : {e}")
        raise ValueError("Fichier non valide. Assurez-vous qu'il s'agit d'un fichier CSV.")

def plot_data_seaborn(df, graph_type, x_axis, y_axis=None, color="#0000FF"):
    """
    Fonction pour générer des graphiques avec Seaborn.
    """
    plt.figure(figsize=(8, 6))
    try:
        logger.info(f"Couleur utilisée pour le graphique Seaborn: {color}")  # Log couleur
        if graph_type == 'scatter':
            sns.scatterplot(data=df, x=x_axis, y=y_axis, color=color)
        elif graph_type == 'hist':
            sns.histplot(df[x_axis], kde=True, color=color)
        elif graph_type == 'bar':
            sns.barplot(data=df, x=x_axis, y=y_axis, color=color)
        elif graph_type == 'count':
            sns.countplot(data=df, x=x_axis, color=color)
        elif graph_type == 'pair':
            sns.pairplot(df, corner=True, diag_kind='kde', plot_kws={'color': color})

        plt.title(f'{graph_type.capitalize()} Graph ({x_axis} vs {y_axis if y_axis else "N/A"})')
        buffer = BytesIO()
        plt.savefig(buffer, format='png')
        buffer.seek(0)
        img_data = base64.b64encode(buffer.read()).decode('utf-8')
        plt.close()
        return img_data
    except Exception as e:
        logger.error(f"Erreur lors de la génération du graphique Seaborn : {e}")
        raise ValueError("Erreur lors de la génération du graphique. Vérifiez vos colonnes.")

def plot_data_matplotlib(df, graph_type, x_axis, y_axis=None, color="#0000FF"):
    """
    Fonction pour générer des graphiques avec Matplotlib.
    """
    plt.figure(figsize=(8, 6))
    try:
        logger.info(f"Couleur utilisée pour le graphique Matplotlib: {color}")  # Log couleur
        if graph_type == 'scatter':
            plt.scatter(df[x_axis], df[y_axis], c=color)
        elif graph_type == 'hist':
            plt.hist(df[x_axis], bins=20, color=color)
        elif graph_type == 'bar':
            plt.bar(df[x_axis], df[y_axis], color=color)
        elif graph_type == 'count':
            df[x_axis].value_counts().plot(kind='bar', color=color)

        plt.title(f'{graph_type.capitalize()} Graph ({x_axis} vs {y_axis if y_axis else "N/A"})')
        buffer = BytesIO()
        plt.savefig(buffer, format='png')
        buffer.seek(0)
        img_data = base64.b64encode(buffer.read()).decode('utf-8')
        plt.close()
        return img_data
    except Exception as e:
        logger.error(f"Erreur lors de la génération du graphique Matplotlib : {e}")
        raise ValueError("Erreur lors de la génération du graphique. Vérifiez vos colonnes.")

def upload_file(request):
    global uploaded_df

    try:
        if request.method == 'POST':
            form = UploadFileForm(request.POST, request.FILES)
            if form.is_valid():
                file = request.FILES['file']
                uploaded_df = handle_uploaded_file(file)
                # Redirection vers la page de visualisation après l'upload
                request.session['uploaded_df'] = uploaded_df.to_json() 
                return redirect('visualize_data')
        else:
            form = UploadFileForm()
        return render(request, 'upload.html', {'form': form})

    except Exception as e:
        logger.error(f"Erreur dans la vue upload_file : {e}")
        return HttpResponse(f"Erreur interne : {e}", status=500)
def clean_data(df, remove_outliers=False, remove_missing_values=False):
    """
    Fonction pour nettoyer les données selon les options sélectionnées.
    """
    if remove_outliers:
        # Détection des valeurs aberrantes : ici, nous utilisons un seuil basé sur l'écart-type pour simplifier.
        z_scores = (df.select_dtypes(include=['float64', 'int64']).apply(lambda x: (x - x.mean()) / x.std()))
        df = df[(z_scores.abs() <= 3).all(axis=1)]  # Supprime les lignes où l'écart-type est supérieur à 3

    if remove_missing_values:
        # Supprimer les lignes contenant des valeurs manquantes
        df = df.dropna()

    return df

def visualize_data(request):
    global uploaded_df

    try:
        if uploaded_df is None:
            return redirect('upload_file')  # Redirige si aucun fichier n'est téléchargé

        plot = None
        visualisation_form = VisualisationForm()
        cleaning_form = DataCleaningForm()  # Formulaire de nettoyage des données

        if request.method == 'POST':
            visualisation_form = VisualisationForm(request.POST)
            cleaning_form = DataCleaningForm(request.POST)  # Récupérer les données du formulaire de nettoyage

            if cleaning_form.is_valid():
                remove_outliers = cleaning_form.cleaned_data['remove_outliers']
                remove_missing_values = cleaning_form.cleaned_data['remove_missing_values']

                # Appliquer le nettoyage des données si l'utilisateur le souhaite
                uploaded_df = clean_data(uploaded_df, remove_outliers, remove_missing_values)  # Appliquer les nettoyages

            if visualisation_form.is_valid():
                graph_type = visualisation_form.cleaned_data['graph_type']
                lib_choice = visualisation_form.cleaned_data['lib_choice']
                x_axis = visualisation_form.cleaned_data['x_axis']
                y_axis = visualisation_form.cleaned_data['y_axis'] or None
                color = visualisation_form.cleaned_data.get('color')  # Récupérer la couleur à partir du formulaire

                # Vérifier si la couleur a été sélectionnée, sinon appliquer une couleur par défaut
                if not color:
                    color = request.POST.get('color', '#0000FF')  # Récupère la couleur du champ input color

                # Vérifier que la couleur est dans le bon format (hexadécimal)
                if not color.startswith('#'):
                    color = '#0000FF'  # Si la couleur n'est pas valide, appliquer une couleur par défaut

                # Génération du graphique en fonction de la bibliothèque choisie
                if lib_choice == 'seaborn':
                    plot = plot_data_seaborn(uploaded_df, graph_type, x_axis, y_axis, color)
                elif lib_choice == 'matplotlib':
                    plot = plot_data_matplotlib(uploaded_df, graph_type, x_axis, y_axis, color)

        # Afficher les 10 premières lignes des données
        data = uploaded_df.head(10).to_html()
        summary = uploaded_df.describe().to_html()

        # Afficher les 5 premières lignes des données après nettoyage
        data_preview = uploaded_df.head(5).to_html()

        return render(request, 'visualize_data.html', {
            'data': data,
            'summary': summary,
            'visualisation_form': visualisation_form,
            'plot': plot,
            'cleaning_form': cleaning_form,
            'data_preview': data_preview,  # Passer les données nettoyées pour affichage
        })

    except Exception as e:
        logger.error(f"Erreur dans la vue visualize_data : {e}")
        return HttpResponse(f"Erreur interne : {e}", status=500)


def index_data(request):
    global uploaded_df

    # Variables pour le contexte
    row_data = None
    col_data = None
    analysis_result = None
    message = None

    try:
        if uploaded_df is None:
            return redirect('upload_file')

        if request.method == 'POST':
            # Vérifiez quel formulaire est soumis
            row_index = request.POST.get('row_index')
            col_name = request.POST.get('col_name')
            analysis_type = request.POST.get('analysis_type')

            # Gestion du formulaire pour la ligne
            if row_index:
                try:
                    row_index = int(row_index)
                    if 0 <= row_index < len(uploaded_df):
                        row_data = uploaded_df.iloc[row_index].to_frame().transpose().to_html()
                    else:
                        message = f"Index {row_index} hors limites."
                except ValueError:
                    message = "L'index doit être un entier valide."

            # Gestion du formulaire pour la colonne
            if col_name and col_name in uploaded_df.columns:
                col_data = uploaded_df[col_name].head(20).to_frame().to_html()

                # Analyse de la colonne
                if analysis_type:
                    col_series = uploaded_df[col_name]
                    if analysis_type == 'missing':
                        missing_values = col_series[col_series.isnull()]
                        missing_values = missing_values.dropna(how='all')  # Supprimer les lignes totalement vides
                        missing_values = missing_values.fillna('Valeur manquante')  # Remplacer NaN par une chaîne lisible

                        analysis_result = {
                            'data': missing_values.to_frame().to_html(),
                            'count': missing_values.isnull().sum()
                        }
                    elif analysis_type == 'duplicates':
                        duplicates = col_series[col_series.duplicated(keep=False)]
                        analysis_result = {
                            'data': duplicates.to_frame().to_html(),
                            'count': duplicates.duplicated(keep=False).sum()
                        }
                    elif analysis_type == 'outliers':
                        if pd.api.types.is_numeric_dtype(col_series):
                             q1 = col_series.quantile(0.25)
                             q3 = col_series.quantile(0.75)
                             iqr = q3 - q1
                             lower_bound = q1 - 1.5 * iqr
                             upper_bound = q3 + 1.5 * iqr
                             outliers = col_series[(col_series < lower_bound) | (col_series > upper_bound)]
                             analysis_result = {
                                'data': outliers.to_frame().to_html(),
                             'count': len(outliers)
                         }
                    else:
                            analysis_result = {
                             'data': None,
                                'count': 0
                                 }
                            message = f"La colonne '{col_name}' n'est pas numérique. L'analyse des valeurs aberrantes n'est pas possible."


        return render(request, 'index_data.html', {
            'row_data': row_data,
            'col_data': col_data,
            'analysis_result': analysis_result,
            'message': message,
        })

    except Exception as e:
        logger.error(f"Erreur dans la vue index_data : {e}")
        return HttpResponse(f"Erreur interne : {e}", status=500)

