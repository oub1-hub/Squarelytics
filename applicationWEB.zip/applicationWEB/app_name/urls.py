# Importation de la fonction path et des vues nécessaires pour gérer les URL
from django.urls import path  # Importation de la fonction path pour associer des URL aux vues
from . import views  # Importation des vues définies dans le fichier views.py

# Définition des URL et des vues associées
urlpatterns = [
    # URL principale pour l'upload de fichier
    path('', views.upload_file, name='upload_file'),  # Lorsqu'un utilisateur accède à la racine du site, la vue 'upload_file' est appelée

    # URL pour visualiser les données téléchargées
    path('visualize/', views.visualize_data, name='visualize_data'),  # La vue 'visualize_data' est appelée pour visualiser les données après téléchargement

    # URL pour l'indexation des données
    path('index/', views.index_data, name='index_data'),  # La vue 'index_data' permet de gérer l'indexation des données

    # URL pour servir une image statique (fichier de type image)
    path('serve-image/', views.serve_static_file, name='serve_image'),  # La vue 'serve_static_file' sert une image à partir des fichiers statiques

    # URL pour la page "About"
    path('about/', views.about, name='about'),  # La vue 'about' sert la page "À propos"

    # URL pour la page "Contact"
    path('contact/', views.contact, name='contact'),  # La vue 'contact' permet de gérer la page "Contact"

    # URL pour télécharger un fichier
    path('upload/', views.upload, name='upload'),  # La vue 'upload' permet de télécharger un fichier (c'est généralement une redirection ou une gestion du formulaire d'upload)

    # URL pour l'indexation des données (encore, avec une autre vue peut-être pour une fonctionnalité similaire)
    path('index_data/', views.index, name='index_data'),  # Une autre vue associée à l'indexation des données
]
