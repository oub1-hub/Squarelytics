# forms.py
from django import forms

class UploadFileForm(forms.Form):
    file = forms.FileField()

class VisualisationForm(forms.Form):
    CHOICES = [
        ('matplotlib', 'Matplotlib'),
        ('seaborn', 'Seaborn'),
    ]
    graph_type = forms.ChoiceField(
        choices=[
            ('scatter', 'Scatter Plot'),
            ('hist', 'Histogram'),
            ('bar', 'Bar Chart'),
            ('count', 'Count Plot'),
            ('pair', 'Pair Plot'),
        ],
        label='Type de graphique'
    )
    lib_choice = forms.ChoiceField(choices=CHOICES, label="Choisir la bibliothèque")
    x_axis = forms.CharField(max_length=100, label="Nom de la colonne pour l'axe X")
    y_axis = forms.CharField(max_length=100, label="Nom de la colonne pour l'axe Y", required=False)

class DataCleaningForm(forms.Form):
    remove_outliers = forms.BooleanField(required=False, initial=False, label="Supprimer les valeurs aberrantes")
    remove_missing_values = forms.BooleanField(required=False, initial=False, label="Supprimer les valeurs manquantes")
class ColumnAnalysisForm(forms.Form):
    CHOICES = [
        ('missing', 'Valeurs manquantes'),
        ('duplicates', 'Doublons'),
        ('outliers', 'Valeurs aberrantes'),
    ]
    col_name = forms.CharField(max_length=100, label="Nom de la colonne")
    analysis_type = forms.ChoiceField(choices=CHOICES, label="Type d'analyse")
